window.sr = ScrollReveal({reset: true});

sr.reveal('.content',{   rotate: {x:100, y:100, z:0},duration: 500})

sr.reveal('.buttons',{ 

  
    duration: 1000
} 
    )