<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        <?php
            require 'css/intro.css';
        ?>
    </style>
    
</head>
<body>

    <div class="circle">
        
    </div>


    <div class="box">
        <div class="box-a">
            <h1>CONHEÇA NOSSO CURSO DE GRAÇA</h1>

        
            <a href="aulas.php">    <button> CONHECER </button></a>
        </div>
    
    </div>
    
</body>
</html>